package com.erkan.diseasediagnosis;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
/*
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;
*/
import com.erkan.diseasediagnosis.R;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import weka.classifiers.Classifier;
import weka.core.Attribute;
import weka.core.Instances;
import weka.core.converters.ConverterUtils;

public class DiagnosingtheDisease extends AppCompatActivity {

    private Toolbar actionBardies;
    private Button makediagnosis;
    private ListView listView;
    SearchView theFilter;
    ArrayAdapter<String> arrayAdapter;
    private EditText weight, height, age, gender, chronic;
    private Classifier mClassifier = null;
   // private FirebaseFirestore fStore;
   // private DatabaseReference bus;
   // FirebaseDatabase db;
    String[] arr;
    ArrayList<Symptom> symptoms = new ArrayList<>();
    ArrayList<String> selectedItems = new ArrayList<>();
    Intent finishIntent;


    public void init(){
        actionBardies = (Toolbar) findViewById(R.id.actionbarr);
        setSupportActionBar(actionBardies);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Diagnosing the Disease");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        theFilter = findViewById(R.id.search);
        this.listView = (ListView)findViewById(R.id.listView);
        this.listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        this.initFillViewData();

        this.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
       //  Log.i("listViewExample", "onItemClick: " + );
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                CheckedTextView v = (CheckedTextView) view;
                boolean currentCheck = v.isChecked();
                Symptom symptom = new Symptom();
                symptom.setName((String)listView.getItemAtPosition(position));
                symptom.setActive(!currentCheck);
                for (Symptom s: symptoms) {
                    if(s.getName().equals(symptom.getName()))
                        s.setActive(currentCheck);
                }
            }
        });

        theFilter.setQueryHint("Search Here");
        listView.setTextFilterEnabled(true);
        theFilter.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            private Runnable mMyRunnable = new Runnable()
            {
                @Override
                public void run()
                {
                    for(int i=0; i<listView.getCount(); i++)
                    {
                        int ind=0;
                        String s = (String)listView.getItemAtPosition(i);
                        for(int j=0; j<arr.length; j++)
                        {
                            if(arr[j].equals(s))
                            {
                                ind=j;
                                break;
                            }
                        }
                        if(symptoms.get(ind).isActive())
                            listView.setItemChecked(i,true);
                        else
                            listView.setItemChecked(i,false);


                    }
                    //Change state here
                   // Log.i("listViewExample", "onItemClick: " + listView.getCount());
                }
            };

            @Override
            public boolean onQueryTextChange(String newText) {
                arrayAdapter.getFilter().filter(newText);

                Handler myHandler = new Handler();
                myHandler.postDelayed(mMyRunnable, 500);
               // Log.i("listViewExample", "onItemClick: " + listView.getItemAtPosition(0));

                return false;
            }
        });

        this.initListViewData();
    }

    private void initListViewData() {

    }

    private void initFillViewData() {
        arr = new String[]{"itching", "skin_rash", "nodal_skin_eruptions", "continuous_sneezing", "shivering", "chills",
                "joint_pain", "stomach_pain", "acidity", "ulcers_on_tongue", "muscle_wasting", "vomiting",
                "burning_micturition", "spotting_urination", "fatigue", "weight_gain", "anxiety", "cold_hands_and_feets",
                "mood_swings", "weight_loss", "restlessness", "lethargy", "patches_in_throat", "irregular_sugar_level",
                "cough", "high_fever", "sunken_eyes", "breathlessness", "sweating", "dehydration", "indigestion", "headache",
                "yellowish_skin", "dark_urine", "nausea", "loss_of_appetite", "pain_behind_the_eyes", "back_pain",
                "constipation", "abdominal_pain", "diarrhoea", "mild_fever", "yellow_urine", "yellowing_of_eyes",
                "acute_liver_failure", "fluid_overload", "swelling_of_stomach", "swelled_lymph_nodes", "malaise",
                "blurred_and_distorted_vision", "phlegm", "throat_irritation", "redness_of_eyes", "sinus_pressure",
                "runny_nose", "congestion", "chest_pain", "weakness_in_limbs", "fast_heart_rate", "pain_during_bowel_movements",
                "pain_in_anal_region", "bloody_stool", "irritation_in_anus", "neck_pain", "dizziness", "cramps", "bruising",
                "obesity", "swollen_legs", "swollen_blood_vessels", "puffy_face_and_eyes", "enlarged_thyroid", "brittle_nails",
                "swollen_extremeties", "excessive_hunger", "extra_marital_contacts", "drying_and_tingling_lips",
                "slurred_speech", "knee_pain", "hip_joint_pain", "muscle_weakness", "stiff_neck", "swelling_joints",
                "movement_stiffness", "spinning_movements", "loss_of_balance", "unsteadiness", "weakness_of_one_body_side",
                "loss_of_smell", "bladder_discomfort", "foul_smell_of_urine", "continuous_feel_of_urine", "passage_of_gases",
                "internal_itching", "toxic_look_(typhos)", "depression", "irritability", "muscle_pain", "altered_sensorium",
                "red_spots_over_body", "belly_pain", "abnormal_menstruation", "dischromic_patches", "watering_from_eyes",
                "increased_appetite", "polyuria", "family_history", "mucoid_sputum", "rusty_sputum", "lack_of_concentration",
                "visual_disturbances", "receiving_blood_transfusion", "receiving_unsterile_injections", "coma",
                "stomach_bleeding", "distention_of_abdomen", "history_of_alcohol_consumption", "blood_in_sputum",
                "prominent_veins_on_calf", "palpitations", "painful_walking", "pus_filled_pimples", "blackheads",
                "scurring", "skin_peeling", "silver_like_dusting", "small_dents_in_nails", "inflammatory_nails", "blister",
                "red_sore_around_nose", "yellow_crust_ooze", "prognosis"};

        int i,n=arr.length;
        for(i=0; i<n; i++)
        {
            Symptom s = new Symptom();
            s.setName(arr[i]);
            s.setActive(false);
            symptoms.add(s);
        }

        // android.R.layout.simple_list_item_checked:
        // ListItem is very simple (Only one CheckedTextView).
        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_multiple_choice , arr);
        this.listView.setAdapter(arrayAdapter);

        i=0;
        for (Symptom s: symptoms) {
            this.listView.setItemChecked(i,s.isActive());
            i++;
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diagnosingthe_disease);

        init();

        makediagnosis = (Button) findViewById(R.id.makediagnosis);

        AssetManager assetManager = getAssets();
        try {
            mClassifier = (Classifier) weka.core.SerializationHelper.read(assetManager.open("smo2.model"));


        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            // Weka "catch'em all!"
            e.printStackTrace();
        }
        Toast.makeText(this, "Model loaded.", Toast.LENGTH_SHORT).show();

        makediagnosis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finishIntent = new  Intent(DiagnosingtheDisease.this, ResultActivity.class);

                for(Symptom s: symptoms){
                    if(s.isActive()) selectedItems.add(s.getName());}

                try {
                    predictSample();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                startActivity(finishIntent);
            }
        });
    }

    private void predictSample() throws Exception {

        String[] classes = {"Fungal infection", "Allergy", "GERD", "Chronic cholestasis", "Drug Reaction", "Peptic ulcer diseae", "AIDS", "Diabetes", "Gastroenteritis", "Bronchial Asthma", "Hypertension", "Migraine", "Cervical spondylosis", "Paralysis (brain hemorrhage)", "Jaundice", "Malaria", "Chicken pox", "Dengue", "Typhoid", "hepatitis A", "Hepatitis B", "Hepatitis C", "Hepatitis D", "Hepatitis E", "Alcoholic hepatitis", "Tuberculosis", "Common Cold", "Pneumonia", "Dimorphic hemmorhoids(piles)", "Heart attack", "Varicose veins", "Hypothyroidism", "Hyperthyroidism", "Hypoglycemia", "Osteoarthristis", "Arthritis", "(vertigo) Paroymsal Positional Vertigo", "Acne", "Urinary tract infection", "Psoriasis", "Impetigo"};
        final List<String> diseases = new ArrayList<String>() {
            {
                this.addAll(Arrays.asList(classes));
            }
        };

      //  Log.i("AddInstance", "HERE: " + data.instance(0).);


        Attribute attributeClass = new Attribute("@@Disease@@", diseases);
        final Attribute Symptom1 = new Attribute("Symptom_1",true);
        final Attribute Symptom2 = new Attribute("Symptom_2",true);
        final Attribute Symptom3 = new Attribute("Symptom_3",true);
        final Attribute Symptom4 = new Attribute("Symptom_4",true);
        final Attribute Symptom5 = new Attribute("Symptom_5",true);
        final Attribute Symptom6 = new Attribute("Symptom_6",true);
        final Attribute Symptom7 = new Attribute("Symptom_7",true);
        final Attribute Symptom8 = new Attribute("Symptom_8",true);
        final Attribute Symptom9 = new Attribute("Symptom_9",true);
        final Attribute Symptom10 = new Attribute("Symptom_10",true);
        final Attribute Symptom11 = new Attribute("Symptom_11",true);
        final Attribute Symptom12 = new Attribute("Symptom_12",true);
        final Attribute Symptom13 = new Attribute("Symptom_13",true);
        final Attribute Symptom14 = new Attribute("Symptom_14",true);
        final Attribute Symptom15 = new Attribute("Symptom_15",true);
        final Attribute Symptom16 = new Attribute("Symptom_16",true);
        final Attribute Symptom17 = new Attribute("Symptom_17",true);

        // Instances(...) requires ArrayList<> instead of List<>...
        ArrayList<Attribute> attributeList = new ArrayList<Attribute>(2) {
            {
                add(attributeClass);
                add(Symptom1);
                add(Symptom2);
                add(Symptom3);
                add(Symptom4);
                add(Symptom5);
                add(Symptom6);
                add(Symptom7);
                add(Symptom8);
                add(Symptom9);
                add(Symptom10);
                add(Symptom11);
                add(Symptom12);
                add(Symptom13);
                add(Symptom14);
                add(Symptom15);
                add(Symptom16);
                add(Symptom17);
            }
        };
        // unpredicted data sets (reference to sample structure for new instances)
        AssetManager assetManager=getAssets();
        ConverterUtils.DataSource source = new ConverterUtils.DataSource(assetManager.open("dataset-new.arff"));
        Instances dataUnpredicted = source.getDataSet();
        // first feature is target variable
        dataUnpredicted.setClassIndex(0);

        int i=1;
        for(String s: selectedItems) {
            dataUnpredicted.instance(0).setValue(i++, s);
        }

        int cap = selectedItems.size();
        if(cap<17)
            for(i=cap; i<17; i++) {
                dataUnpredicted.instance(0).setValue(i, "x");
            }

        /*DenseInstance newInstance = new DenseInstance(dataUnpredicted.numAttributes()) {
            {
               // Log.i("AddInstance", "HERE: " + selectedItems.get(0));
                setValue(attributeClass, "GERD");
                int i=1;
                for(String s: selectedItems)
                {
                    setValue(attributeList.get(i++),s);
                }
                *//*
                setValue(Symptom1, selectedItems.get(0));
                setValue(Symptom2, selectedItems.get(1));
                setValue(Symptom3, selectedItems.get(2));
                setValue(Symptom4, selectedItems.get(3));
                setValue(Symptom5, selectedItems.get(4));
                setValue(Symptom6, selectedItems.get(5));
                setValue(Symptom7, selectedItems.get(6));
                setValue(Symptom8, selectedItems.get(7));
                setValue(Symptom9, selectedItems.get(8));
                setValue(Symptom10, selectedItems.get(9));
                setValue(Symptom11, selectedItems.get(10));
                setValue(Symptom12, selectedItems.get(11));
                setValue(Symptom13, selectedItems.get(12));
                setValue(Symptom14, selectedItems.get(13));
                setValue(Symptom15, selectedItems.get(14));
                setValue(Symptom16, selectedItems.get(15));
                setValue(Symptom17, selectedItems.get(16));*//*
            }
        };*/


        // reference to dataset
       // newInstance.setDataset(dataUnpredicted);

        // predict new sample
        try {
           // Log.d("SelectedItems", newInstance.toString());
            double result = mClassifier.classifyInstance(dataUnpredicted.instance(0));

            String className = diseases.get(Double.valueOf(result).intValue());
            finishIntent.putExtra("result",className);
            String msg = "predicted: " + className;
          //  Log.d("WEKA_TEST", msg);
          //  Log.d("WEKA_TEST", selectedItems.toString());
          //  Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}