package com.erkan.diseasediagnosis;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.erkan.diseasediagnosis.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


public class ResultActivity extends AppCompatActivity {

    private Toolbar actionBar;
    TextView disease,prec1,prec2,prec3,prec4;
    Map<Object, ArrayList<String>> map = new HashMap<>();


    public void init(){
        actionBar = (Toolbar) findViewById(R.id.cardViewBar);
        disease = (TextView) findViewById(R.id.disease_res);
        prec1 = (TextView) findViewById(R.id.prec1);
        prec2 = (TextView) findViewById(R.id.prec2);
        prec3 = (TextView) findViewById(R.id.prec3);
        prec4 = (TextView) findViewById(R.id.prec4);

        setSupportActionBar(actionBar);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Diagnosis Result");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

            BufferedReader reader = null;
            try {
                reader = new BufferedReader(
                        new InputStreamReader(getAssets().open("symptom_precaution.csv"), "UTF-8"));

                // do reading, usually loop until end of file reading
                String line;
                int i=0;
                while ((line = reader.readLine()) != null) {
                    if (i++ == 0) continue;
                    String[] strings = line.split(",");

                    String disease = strings[0].trim();
                    ArrayList<String> arrayList = new ArrayList<>();
                    for (int j = 1; j < strings.length; j++) {
                        if(!strings[j].equals(""))
                            arrayList.add(strings[j]);
                    }
                    map.put(disease,arrayList);
                }
            } catch (IOException e) {
                //log the exception
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        //log the exception
                    }
                }
            }


            Intent intent = getIntent();
            String result = intent.getStringExtra("result");
            Log.d("WEKA_TEST", result);
            Log.d("WEKA_TEST", map.get(result).toString());
            ArrayList<String> list =  map.get(result);
            disease.setText(result);
            prec1.setText(list.get(0));
            prec2.setText(list.get(1));
            prec3.setText(list.get(2));
            if(list.size()==4)
                prec4.setText(list.get(3));

            Log.d("WEKA_TEST", map.get(result).toString());

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        init();
    }
}