package com.erkan.diseasediagnosis;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.erkan.diseasediagnosis.R;
/*
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
*/
import java.util.Objects;

public class infoPages extends AppCompatActivity {

    private Toolbar actionBarInfo;
    private Button save;
    private EditText weight, height, age, gender, chronic;
  //  private FirebaseFirestore fStore;
  //  private DatabaseReference bus;
   // FirebaseDatabase db;


    public void init() {
        actionBarInfo = (Toolbar) findViewById(R.id.infoActionBar);
        setSupportActionBar(actionBarInfo);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Personel İnformation");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        weight = (EditText) findViewById(R.id.weight);
        height = (EditText) findViewById(R.id.height);
        age = (EditText) findViewById(R.id.age);
        gender = (EditText) findViewById(R.id.gender);
        chronic = (EditText) findViewById(R.id.disease);

//        auth = FirebaseAuth.getInstance();
//        userID = auth.getCurrentUser().getUid();
      //  db = FirebaseDatabase.getInstance();
       // fStore = FirebaseFirestore.getInstance();
       // bus = FirebaseDatabase.getInstance().getReference();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_pages);
        init();

        save = (Button) findViewById(R.id.btn_save);


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VerileriGir();
            }
        });
    }

    private void VerileriGir() {

        Intent intentcik = new Intent(infoPages.this, DiagnosingtheDisease.class);
        startActivity(intentcik);

//        Toast.makeText(this, "Boş Alan Bırakmayınız!", Toast.LENGTH_LONG).show();
//        String key = bus.push().getKey();
//        DatabaseReference vy = db.getReference("kisiler").child(key);
//        bus.child("Users").child(key).setValue("bokk");


//
//        String e_weight = weight.getText().toString();
//        String e_height = height.getText().toString();
//        String e_age = age.getText().toString();
//        String e_disease = chronic.getText().toString();
//        String e_gender = gender.getText().toString();
//
//        if (TextUtils.isEmpty(e_weight) || (TextUtils.isEmpty(e_height)) || (TextUtils.isEmpty(e_age)) || (TextUtils.isEmpty(e_disease)) || (TextUtils.isEmpty(e_gender))){
//            Toast.makeText(infoPages.this, "Boş Alan Bırakmayınız", Toast.LENGTH_LONG).show();
//        }else{
//            HashMap<String,String> pp = new HashMap<>();
//            pp.put("uid",userID);
//            pp.put("e_weight",e_weight);
//            pp.put("e_height",e_height);
//            pp.put("e_age",e_age);
//            pp.put("e_disease",e_disease);
//            pp.put("e_gender",e_gender);
//
//            bus.child("Users").child(userID).setValue(pp).addOnCompleteListener(new OnCompleteListener<Void>() {
//                @Override
//                public void onComplete(@NonNull Task<Void> task) {
//                    if (task.isSuccessful()){
//                        Toast.makeText(infoPages.this, "Bilgileriniz Başarılı Şekilde Kayıt Edildi...",Toast.LENGTH_LONG).show();
//
//                        Intent intentBasari = new Intent(infoPages.this, MainActivity.class);
//                        startActivity(intentBasari);
//                        finish();
//                    }
//                    else{
//                        String mesaj = task.getException().toString();
//                        Toast.makeText(infoPages.this,"Hata: "+mesaj,Toast.LENGTH_LONG).show();
//                    }
//                }
//
//            });
//        }
//
//
//


//        final Intent kisikaydetIntent = new Intent(infoPages.this, MainActivity.class);
//        String key = bus.push().getKey();
//        DatabaseReference vy = db.getReference("Users");
//
//        String e_weight = weight.getText().toString();
//        String e_height = height.getText().toString();
//        String e_age = age.getText().toString();
//        String e_disease = chronic.getText().toString();
//        String e_gender = gender.getText().toString();
//
//        if (TextUtils.isEmpty(e_weight) || (TextUtils.isEmpty(e_height) || (TextUtils.isEmpty(e_age)) || (TextUtils.isEmpty(e_disease)) || (TextUtils.isEmpty(e_gender)) )) {
//            Toast.makeText(infoPages.this, "Boş Alan Bırakmayınız!", Toast.LENGTH_LONG).show();
//        }else {
//            HashMap<String, String> pp = new HashMap<>();
//            pp.put("key", key);
//            pp.put("e_weight", e_weight);
//            pp.put("e_height", e_height);
//            pp.put("e_age", e_age);
//            pp.put("e_disease", e_disease);
//            pp.put("e_gender", e_gender);
//
//            bus.child("Users").setValue(pp).addOnCompleteListener(new OnCompleteListener<Void>() {
//                @Override
//                public void onComplete(@NonNull Task<Void> task) {
//                    if (task.isSuccessful()){
//                        Toast.makeText(infoPages.this, "Bilgileriniz Başarılı Şekilde Kayıt Edildi...",Toast.LENGTH_LONG).show();
//
//                        Intent intentBasari = new Intent(infoPages.this, MainActivity.class);
//                        startActivity(intentBasari);
//                        finish();
//                    }
//                    else{
//                        String mesaj = task.getException().toString();
//                        Toast.makeText(infoPages.this,"Hata: "+mesaj,Toast.LENGTH_LONG).show();
//                    }
//                }
//
//            });


    }
}